#!/usr/bin/env python3
"""Assemble local scene assets. No network, credentials, uploads, or queue writes."""

import argparse
import hashlib
import json
import math
import re
import shutil
import subprocess
import sys
import wave
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def executable(value):
    found = shutil.which(value)
    if found:
        return found
    path = Path(value).expanduser()
    require(path.is_file(), f"Executable not found: {value}")
    return str(path.resolve())


def command(args, timeout=1800):
    result = subprocess.run(list(map(str, args)), capture_output=True,
                            text=True, encoding="utf-8", errors="replace",
                            timeout=timeout)
    if result.returncode:
        raise RuntimeError(result.stderr[-4000:] or "Media command failed")
    return result


def probe(fp, path):
    return json.loads(command([fp, "-v", "error", "-show_streams", "-show_format",
                               "-of", "json", path], timeout=120).stdout)


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def number(settings, key, default, minimum, maximum, integer=False):
    value = settings.get(key, default)
    require(isinstance(value, (int, float)) and not isinstance(value, bool),
            f"settings.{key} must be numeric")
    require(math.isfinite(value) and minimum <= value <= maximum,
            f"settings.{key} must be between {minimum} and {maximum}")
    require(not integer or value == int(value), f"settings.{key} must be an integer")
    return int(value) if integer else float(value)


def local_asset(base, name):
    require(isinstance(name, str) and name.strip(), "Missing asset path")
    require(not Path(name).is_absolute(), "Asset paths must be relative to the manifest")
    path = (base / name).resolve()
    require(path.is_relative_to(base), "Asset path leaves the run directory")
    require(path.is_file(), f"Missing asset: {name}")
    return path


def inspect(manifest, fp):
    base = manifest.parent.resolve()
    data = json.loads(manifest.read_text(encoding="utf-8-sig"))
    require(data.get("schema_version") == 1, "Expected schema_version 1")
    settings = data.get("settings", {})
    require(isinstance(settings, dict), "settings must be an object")
    n = number(settings, "scene_count", 9, 1, 30, True)
    seconds = number(settings, "scene_seconds", 8, 0.1, 60)
    width = number(settings, "width", 720, 16, 4096, True)
    height = number(settings, "height", 1280, 16, 4096, True)
    fps = number(settings, "fps", 30, 1, 120, True)
    gain = number(settings, "ambient_gain", 0.5, 0, 1)
    lower = number(settings, "raw_audio_min_seconds", 5, 0.1, 60)
    upper = number(settings, "raw_audio_max_seconds", 10, 0.1, 120)
    require(lower <= upper, "Raw audio minimum exceeds maximum")
    require(width % 2 == 0 and height % 2 == 0, "H.264 yuv420p requires even dimensions")
    require(abs(seconds * fps - round(seconds * fps)) < 1e-6,
            "Scene length must contain a whole number of video frames")
    require(abs(seconds * 48000 - round(seconds * 48000)) < 1e-6,
            "Scene length must contain a whole number of audio samples")
    languages = settings.get("languages", ["ko", "en"])
    require(isinstance(languages, list) and 1 <= len(languages) <= 10
            and all(isinstance(lang, str) and re.fullmatch(r"[a-z]{2,3}", lang)
                    for lang in languages)
            and len(set(languages)) == len(languages), "Invalid language list")
    primary = settings.get("primary_language", "ko")
    require(primary in languages, "Primary language must be in languages")
    scenes = data.get("scenes", [])
    require(isinstance(scenes, list) and len(scenes) == n, "Scene count mismatch")
    assets, evidence, clip_paths, clip_hashes = [], [], set(), set()
    for index, scene in enumerate(scenes, 1):
        require(isinstance(scene, dict) and type(scene.get("id")) is int and scene["id"] == index,
                "Scene IDs must be 1..N in order")
        require(isinstance(scene.get("narration"), dict) and isinstance(scene.get("audio"), dict),
                f"Scene {index}: narration and audio must be objects")
        require(isinstance(scene.get("caption", {}), dict),
                f"Scene {index}: caption must be an object")
        for key in ("visual_action", "flow_prompt"):
            require(isinstance(scene.get(key), str) and scene[key].strip(),
                    f"Scene {index}: fill {key}")
        clip = local_asset(base, scene.get("clip"))
        require(clip not in clip_paths, f"Scene {index}: repeated clip path")
        clip_paths.add(clip)
        info = probe(fp, clip)
        video = next((s for s in info["streams"] if s["codec_type"] == "video"), None)
        require(video is not None, f"Scene {index}: no video stream")
        require((video["width"], video["height"]) == (width, height),
                f"Scene {index}: expected {width}x{height}")
        duration = float(video.get("duration", info["format"]["duration"]))
        require(math.isfinite(duration) and duration >= seconds - 0.05,
                f"Scene {index}: video too short ({duration:.3f}s)")
        clip_hash = digest(clip)
        require(clip_hash not in clip_hashes, f"Scene {index}: identical clip bytes reused")
        clip_hashes.add(clip_hash)
        speech = {}
        for lang in languages:
            text = scene.get("narration", {}).get(lang)
            require(isinstance(text, str) and text.strip(),
                    f"Scene {index}: fill narration.{lang}")
            if lang in scene.get("caption", {}):
                caption = scene["caption"][lang]
                require(isinstance(caption, str) and caption.strip(),
                        f"Scene {index}: caption.{lang} must not be empty")
            path = local_asset(base, scene.get("audio", {}).get(lang))
            audio_info = probe(fp, path)
            require(any(s["codec_type"] == "audio" for s in audio_info["streams"]),
                    f"Scene {index}/{lang}: no audio stream")
            raw_seconds = float(audio_info["format"]["duration"])
            require(math.isfinite(raw_seconds) and lower <= raw_seconds <= upper,
                    f"Scene {index}/{lang}: raw TTS {raw_seconds:.3f}s; "
                    f"required {lower:g}..{upper:g}s, revise this narration")
            speech[lang] = {"path": path, "seconds": raw_seconds, "sha256": digest(path)}
        assets.append({"clip": clip, "has_audio": any(
            s["codec_type"] == "audio" for s in info["streams"]), "speech": speech})
        evidence.append({"id": index, "clip": str(clip.relative_to(base)),
                         "clip_seconds": duration, "clip_sha256": clip_hash,
                         "audio": {lang: {"path": str(item["path"].relative_to(base)),
                                          "raw_seconds": item["seconds"],
                                          "sha256": item["sha256"]}
                                   for lang, item in speech.items()}})
    config = {"n": n, "seconds": seconds, "width": width, "height": height,
              "fps": fps, "gain": gain, "languages": languages, "primary": primary}
    return data, config, assets, evidence


def ff(ffmpeg, args):
    command([ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-n", *args])


def stamp(seconds):
    ms = round(seconds * 1000)
    hours, rest = divmod(ms, 3600000)
    minutes, rest = divmod(rest, 60000)
    sec, milli = divmod(rest, 1000)
    return f"{hours:02}:{minutes:02}:{sec:02},{milli:03}"


def exact_wav(path, frames):
    with wave.open(str(path), "rb") as audio:
        require(audio.getframerate() == 48000 and audio.getnframes() == frames,
                f"PCM timeline mismatch: {path.name}")


def assemble(data, cfg, assets, evidence, output, ffmpeg, fp):
    output.mkdir(parents=True, exist_ok=False)
    sec, n = cfg["seconds"], cfg["n"]
    total = sec * n
    pcm_format = "aresample=48000,aformat=sample_fmts=s16:channel_layouts=stereo"
    normalized = {}
    for lang in cfg["languages"]:
        target = output / "normalized" / lang
        target.mkdir(parents=True)
        normalized[lang] = []
        for i, asset in enumerate(assets, 1):
            item = asset["speech"][lang]
            tempo = max(1.0, item["seconds"] / sec)
            tempo_filters = []
            while tempo > 2:
                tempo_filters.append("atempo=2")
                tempo /= 2
            tempo_filters.append(f"atempo={tempo:.10f}")
            filters = ",".join([*tempo_filters, pcm_format, "apad",
                                f"atrim=end_sample={round(sec * 48000)}", "asetpts=PTS-STARTPTS"])
            dest = target / f"scene_{i:02}.wav"
            ff(ffmpeg, ["-i", item["path"], "-map", "0:a:0", "-af", filters,
                        "-c:a", "pcm_s16le", dest])
            exact_wav(dest, round(sec * 48000))
            normalized[lang].append(dest)

    inputs, filters = [], []
    for i, asset in enumerate(assets):
        inputs.extend(["-i", asset["clip"]])
        filters.append(f"[{i}:v:0]tpad=stop_mode=clone:stop_duration=0.05,"
                       f"trim=duration={sec},setpts=PTS-STARTPTS,fps={cfg['fps']},setsar=1[v{i}]")
        if asset["has_audio"]:
            filters.append(f"[{i}:a:0]{pcm_format},apad,atrim=duration={sec},"
                           f"asetpts=PTS-STARTPTS[a{i}]")
        else:
            filters.append(f"anullsrc=r=48000:cl=stereo,atrim=duration={sec},"
                           f"asetpts=PTS-STARTPTS[a{i}]")
    filters.append("".join(f"[v{i}][a{i}]" for i in range(n))
                   + f"concat=n={n}:v=1:a=1[v][a]")
    concat = output / "concat_video.mp4"
    ff(ffmpeg, [*inputs, "-filter_complex_threads", "1", "-filter_complex", ";".join(filters),
                "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-threads", "2",
                "-preset", "fast", "-crf", "18", "-pix_fmt", "yuv420p", "-c:a", "aac",
                "-b:a", "192k", "-t", str(total), "-movflags", "+faststart", concat])
    for lang, paths in normalized.items():
        wav = output / f"combined_{lang}.wav"
        inputs = [v for path in paths for v in ("-i", path)]
        chain = "".join(f"[{i}:a:0]" for i in range(n)) + f"concat=n={n}:v=0:a=1[a]"
        ff(ffmpeg, [*inputs, "-filter_complex", chain, "-map", "[a]", "-c:a", "pcm_s16le", wav])
        exact_wav(wav, round(total * 48000))
        ff(ffmpeg, ["-i", wav, "-c:a", "libmp3lame", "-b:a", "192k",
                    output / f"combined_{lang}.mp3"])
        cues = []
        for i, scene in enumerate(data["scenes"]):
            text = scene.get("caption", {}).get(lang, scene["narration"][lang])
            require(isinstance(text, str) and text.strip(), f"Invalid caption: {lang}/{i+1}")
            cues.append(f"{i+1}\n{stamp(i * sec)} --> {stamp((i+1) * sec)}\n{text.strip()}\n")
        (output / f"captions_{lang}.srt").write_text("\n".join(cues), encoding="utf-8")
    if "en" in cfg["languages"]:
        shutil.copy2(output / "combined_en.mp3", output / "audio_en.mp3")
    final = output / "final_video.mp4"
    mix = (f"[0:a:0]volume={cfg['gain']}[ambient];[ambient][1:a:0]"
           "amix=inputs=2:normalize=0:duration=first,alimiter=limit=0.97:level=false:latency=1[a]")
    ff(ffmpeg, ["-i", concat, "-i", output / f"combined_{cfg['primary']}.wav",
                "-filter_complex", mix, "-map", "0:v:0", "-map", "[a]", "-c:v", "copy",
                "-c:a", "aac", "-b:a", "192k", "-t", str(total),
                "-movflags", "+faststart", final])
    columns = math.ceil(math.sqrt(n))
    rows = math.ceil(n / columns)
    ff(ffmpeg, ["-ss", str(sec / 2), "-i", final, "-vf",
                f"fps=1/{sec},scale=180:-2,tile={columns}x{rows}:nb_frames={n}",
                "-frames:v", "1", "-update", "1", output / "contact_sheet.jpg"])
    results = {}
    for path in (concat, final):
        info = probe(fp, path)
        actual = float(info["format"]["duration"])
        require(abs(actual - total) <= 0.1, f"Final duration mismatch: {path.name}")
        video = next(s for s in info["streams"] if s["codec_type"] == "video")
        require((video["width"], video["height"]) == (cfg["width"], cfg["height"]),
                "Final dimensions changed")
        require(any(s["codec_type"] == "audio" for s in info["streams"]), "No final audio")
        results[path.name] = {"seconds": actual, "width": video["width"], "height": video["height"],
                              "sha256": digest(path)}
    loudness = command([ffmpeg, "-hide_banner", "-nostdin", "-i", final,
                        "-vn", "-af", "volumedetect", "-f", "null", "-"]).stderr
    peak = re.search(r"max_volume:\s*([\d.\-]+|\-inf) dB", loudness)
    for asset, record in zip(assets, evidence):
        require(digest(asset["clip"]) == record["clip_sha256"], "Source clip changed during editing")
        for lang, item in asset["speech"].items():
            require(digest(item["path"]) == item["sha256"], "Source audio changed during editing")
    report = {"automatic_checks_passed": True, "visual_review_complete": False,
              "listening_review_complete": False, "science_fact_check_by_script": False,
              "run_id": data.get("run_id"), "expected_seconds": total,
              "outputs": results, "max_volume_dbfs": peak.group(1) if peak else None,
              "sources": evidence, "originals_unchanged": True,
              "subtitle_timing": "one cue per scene; not word-aligned",
              "english_dub": "narration only; ambient not included",
              "queue_modified": False, "uploaded": False}
    (output / "assembly_validation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--output", type=Path, default=Path("final-v1"))
    parser.add_argument("--check-only", action="store_true")
    parser.add_argument("--ffmpeg", default="ffmpeg")
    parser.add_argument("--ffprobe", default="ffprobe")
    args = parser.parse_args()
    manifest = args.manifest.resolve()
    try:
        require(manifest.is_file(), "Manifest not found")
        fp = executable(args.ffprobe)
        data, cfg, assets, evidence = inspect(manifest, fp)
        if args.check_only:
            print(json.dumps({"inputs_valid": True, "scenes": cfg["n"],
                              "languages": cfg["languages"], "seconds": cfg["n"] * cfg["seconds"],
                              "files_written": False}))
            return 0
        output = args.output if args.output.is_absolute() else manifest.parent / args.output
        output = output.resolve()
        require(output.is_relative_to(manifest.parent), "Output must be inside the run directory")
        require(not output.exists(), "Output already exists; choose a new version directory")
        report = assemble(data, cfg, assets, evidence, output, executable(args.ffmpeg), fp)
        print(json.dumps({"automatic_checks_passed": report["automatic_checks_passed"],
                          "seconds": report["expected_seconds"],
                          "visual_and_listening_review_required": True}, ensure_ascii=False))
        return 0
    except (ValueError, RuntimeError, OSError, KeyError, TypeError, StopIteration,
            subprocess.TimeoutExpired) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
